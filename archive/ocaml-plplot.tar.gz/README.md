# OCaml bindings to the PLplot library

[PLplot][] is a library for creating scientific plots.

# Installation

The library is available in [opam][]:
```
opam install plplot
```

[opam]: https://opam.ocaml.org/
[PLplot]: https://sourceforge.net/projects/plplot/
